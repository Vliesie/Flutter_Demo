import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginPage extends StatefulWidget{ //Stateless = Constant

  @override
  State<StatefulWidget> createState() {
    return new _LoginPageState();

  }

}

enum FormType{
  login,
  register
}

class _LoginPageState extends State<LoginPage> {

  final formKey = new GlobalKey<FormState>();

  String _email;
  String _password;
  FormType _formType = FormType.login;
  String _title = 'Login';

  bool validateAndSave(){
    final form = formKey.currentState;


    if (form.validate())
    {
      form.save();
      return true;

    }
    else{
      return false;
    }
  }
  void validateAndSubmit() async{
    if(validateAndSave()){
      try {
        if(_formType == FormType.login){
          FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password);
          print('Signed in: ${user.uid}');
        }
        else{
          FirebaseUser user = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: _email, password: _password);
          print('Registed user: ${user.uid}');
        }

      }
      catch(error){
        print('error: $error');
      }
    }

  }

  void moveToRegister(){
    _title = 'Register';
    formKey.currentState.reset();
    setState(() {
      _formType = FormType.register;
    });
  }

  void moveToLogin() {
    _title = 'Login';
    formKey.currentState.reset();
    setState(() {
      _formType = FormType.login;
    });

  }


  @override
  Widget build(BuildContext context) {
    return new Scaffold
      (appBar: new AppBar(
      title: new Text('$_title'),
    ),
        body: new Container(
            padding: EdgeInsets.all(16.0),
            child: new Form(
                key: formKey,
                child: new Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: buildInputs() + BuildButtons(),
                )
            )
        )
    );
  }

  List<Widget> buildInputs(){
    return [ new TextFormField(
      decoration: new InputDecoration(labelText: 'Email'),
      validator: (value) => value.isEmpty ? 'Email can\'t be Empty': null,
      onSaved: (value) => _email = value,
    ),
    new TextFormField(
      decoration: new InputDecoration(labelText: 'Password'),
      validator: (value) => value.isEmpty ? 'Password can\'t be Empty': null,
      onSaved: (value) => _password = value,
    )];

  }


  List<Widget> BuildButtons(){

    if(_formType == FormType.login){

      return [
        new RaisedButton(child: new Text('Login', style: new TextStyle(fontSize: 20.0)
        ),
          onPressed: validateAndSubmit,
        ),
        new FlatButton(
          child: new Text('Need an acount?' , style: new TextStyle(fontSize: 13.0)),
          onPressed: moveToRegister,
        )

      ];
    }
    else{
      return [
        new RaisedButton(child: new Text('Create Account', style: new TextStyle(fontSize: 20.0)
        ),
          onPressed: validateAndSubmit,
        ),
        new FlatButton(
          child: new Text('Already have an Account?' , style: new TextStyle(fontSize: 13.0)),
          onPressed: moveToLogin,
        )

      ];
    }
  }
}
